//
//  RelevantModel.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RelevantModel : NSObject

@property (nonatomic, copy) NSString *guid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *mediaUrl;
@property (nonatomic, copy) NSString *mediaUrl1;
@property (nonatomic, copy) NSString *createDate;
@property (nonatomic, copy) NSString *playTime;
@property (nonatomic, copy) NSString *duration;
@property (nonatomic, copy) NSString *columnName;
@property (nonatomic, copy) NSString *seTitle;
@property (nonatomic, copy) NSString *cpName;
@property (nonatomic, copy) NSString *searchPath;
@property (nonatomic, strong) NSArray *files;
@property (nonatomic, copy) NSString *itemId;
@property (nonatomic, copy) NSString *shareUrl;



@end
