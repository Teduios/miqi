//
//  RelevantModel.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "RelevantModel.h"

@implementation RelevantModel

@end
