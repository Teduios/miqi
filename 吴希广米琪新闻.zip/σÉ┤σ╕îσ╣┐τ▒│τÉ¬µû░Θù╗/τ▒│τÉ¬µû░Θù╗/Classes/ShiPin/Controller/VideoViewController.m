//
//  VideoViewController.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "VideoViewController.h"

#import "AFNetworking.h"
#import "MBProgressHUD+MJ.h"
#import "Masonry.h" // 自动布局的第三方
#import "iCarousel.h" // 头部滚动视图第三方，还有更多炫酷功能（请百度）
#import "NSTimer+BlocksKit.h" // 改变系统的target+selector模式为 block模式。 带来紧凑的代码风格，高效率的回调执行
#import "UIImageView+WebCache.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "MBProgressHUD+MJ.h"
#import "MMProgressHUD.h"

#import "VideoModel.h"
#import "VideoHeaderModel.h"
#import "VideoHeaderCell.h"
#import "VideoCell.h"
#import "PlayViewController.h"

@interface VideoViewController ()<iCarouselDelegate,iCarouselDataSource>

@property (nonatomic, strong) NSMutableArray *headerArr;
@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, assign) NSInteger page;

@property (nonatomic) BOOL isRefreshing;
@property (nonatomic) BOOL isLoadMore;


//@property (nonatomic, strong) VideoHeaderCell *headerCell;
//@property (nonatomic, strong) VideoCell *cell;

@end

@implementation VideoViewController{

    // 添加成员变量，因为不需要懒加载，所以不需要声明成属性
    iCarousel *_ic;
    UIPageControl *_pageControl;
    UILabel *_titleLable;
    NSTimer *_timer;

}


- (NSMutableArray *)headerArr {

    if (!_headerArr) {
    
        _headerArr = [NSMutableArray array];
    }
    return _headerArr;
}

- (NSMutableArray *)dataArr {

    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }

    return _dataArr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self fristDownlode];
    [self addUI];
    [self addRefresh];

}

- (void)addUI{
    
   // [self.tableView registerClass:[VideoHeaderCell class] forCellReuseIdentifier:@"Cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"VideoCell" bundle:nil] forCellReuseIdentifier:@"VideoCellID"];
    
//    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight * 1/3)];
//    
//    [headerView addSubview:[self headerView]];
//    self.tableView.tableHeaderView = headerView;
//
//    [self.tableView reloadData];
//    
    
}

- (void)addRefresh {
    
    __weak typeof(self) weakSelf = self;
    // 下拉刷新
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        if (weakSelf.isRefreshing) {
            return;
        }
        weakSelf.isRefreshing = YES;
        weakSelf.page = 1;
        NSString *url = @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.1&isNotModified=0&useType=androidPhone&channelId=100409-0&positionId=0";
        NSString *newUrl = [url stringByAppendingString:@"&page=%d"];
        NSString *newURL = [NSString stringWithFormat:newUrl,self.page];
        [self DownLoadDataWithUrl:newURL];
        
        // 结束刷新
        [self endRefreshing];
        
        //        // 模拟延迟加载数据，因此2秒后才调用（真实开发中，可以移除这段gcd代码）
        //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //
        //            });
    }];
    
    // 设置自动切换透明度(在导航栏下面自动隐藏)
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    
    // 上拉刷新
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        
        if (weakSelf.isLoadMore) {
            return;
        }
        weakSelf.isLoadMore = YES;
        weakSelf.page ++;
        NSString *url = @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.1&isNotModified=0&useType=androidPhone&channelId=100409-0&positionId=0";
        NSString *newUrl = [url stringByAppendingString:@"&page=%d"];
        NSString *newURL = [NSString stringWithFormat:newUrl,self.page];
        [self DownLoadDataWithUrl:newURL];
        // 结束刷新
        [self endRefreshing];
        
    }];
    
}

- (void)endRefreshing {
    if (self.isRefreshing) {
        self.isRefreshing = NO;//标记刷新结束
        //正在刷新 就结束刷新
        [self.tableView.mj_header endRefreshing];
    }
    if (self.isLoadMore) {
        self.isLoadMore = NO;
        [self.tableView.mj_footer endRefreshing];
    }
}

- (void)fristDownlode{
    self.page = 1;
    NSString *url = @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.1&isNotModified=0&useType=androidPhone&channelId=100409-0&positionId=0";
    NSString *newUrl = [url stringByAppendingString:@"&page=%d"];
    NSString *newURL = [NSString stringWithFormat:newUrl,self.page];
    [self DownLoadDataWithUrl:newURL];
    
}

- (void)DownLoadDataWithUrl:(NSString *)url{
    
    NSArray *arr = [url componentsSeparatedByString:@"?"];
    NSString *baseUrl = [arr firstObject];
    
    NSString *para = [arr lastObject];
    
    NSArray *paras = [para componentsSeparatedByString:@"&"];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    for (int i = 0; i < paras.count; i++) {
        NSString *abc = paras[i];
        NSArray *abd = [abc componentsSeparatedByString:@"="];
        dic[abd[0]] = abd[1];
    }
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager GET:baseUrl parameters:dic success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {

        if (self.page == 1) {
            [self.dataArr removeAllObjects];
        }
         NSArray *headerArray = responseObject[@"header"];
//        //*下载动画
//        [MMProgressHUD setPresentationStyle:MMProgressHUDPresentationStyleFade];
//        [MMProgressHUD showWithTitle:@"请等待" status:@"加载中..."];
        
        for (NSDictionary *dict in headerArray) {
            VideoHeaderModel *headerModel = [[VideoHeaderModel alloc] init];
            headerModel.title = dict[@"title"];
            headerModel.image = dict[@"image"];
            [self.headerArr addObject:headerModel];

        }
        //[self addUI];
        _ic.delegate = self;
        _ic.dataSource = self;
        
        
        NSArray *array = responseObject[@"bodyList"];
        for (NSDictionary *dict in array) {
            
            NSArray *videoListArr = dict[@"videoList"];
            
            for (NSDictionary *videoListDic in videoListArr) {
                
                VideoModel *model = [[VideoModel alloc] init];
                model.image = videoListDic[@"image"];
                model.title = videoListDic[@"title"];
                
                model.duration = videoListDic[@"memberItem"][@"duration"];
                model.createDate = videoListDic[@"memberItem"][@"createDate"];
                model.guid = videoListDic[@"memberItem"][@"guid"];
        
                [self.dataArr addObject:model];
            }

        }
        
        [self.tableView reloadData];
//        [MMProgressHUD dismissWithSuccess:@"加载成功" title:@"OK"];
        [MBProgressHUD showSuccess:@"加载成功" toView:self.view];
        
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
//        [MBProgressHUD showError:@"数据加载失败" toView:self.view];
        [MBProgressHUD showError:@"加载失败" toView:self.view];
    }];
 
}

- (UIView *)headerView{

    [_timer invalidate];
    
    VideoHeaderModel *model = [[VideoHeaderModel alloc] init];
    
    
    // 如果当前没有头部视图，返回nil
//    if (self.headerArr.count == nil && self.headerArr.count == 0) {
//        return nil;
//    }
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(260, 10, 0, kScreenHeight * 1/3)];
    headerView.backgroundColor = [UIColor redColor];
    UIView *botoomView = [UIView new];
    botoomView.backgroundColor = kRGBColor(240, 240, 240);
    [headerView addSubview:botoomView];
    
    // botoomView添加约束
    [botoomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.mas_equalTo(0);
        make.height.mas_equalTo(35);
        
    }];
    
    _titleLable = [UILabel new];
    _titleLable.backgroundColor = [UIColor greenColor];
    [botoomView addSubview:_titleLable];
    [_titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    _pageControl = [UIPageControl new];
    _pageControl.numberOfPages = self.headerArr.count;
    [botoomView addSubview:_pageControl];
    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(-10);
        make.centerY.mas_equalTo(0);
        make.width.mas_lessThanOrEqualTo(60); // 小于等于
        make.width.mas_greaterThanOrEqualTo(20); // 大于等于
        make.left.mas_equalTo(_titleLable.mas_right).mas_equalTo(-10);
    }];
    
    _titleLable.text = model.title;
    _ic.delegate = self;
    _ic.dataSource = self;
    
    // 添加滚动栏
    _ic = [iCarousel new];
    [headerView addSubview:_ic];
    [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_equalTo(0);
        make.bottom.mas_equalTo(botoomView.mas_top).mas_equalTo(0);
    }];

    _ic.pagingEnabled = YES;
    _ic.scrollSpeed = 1;
    
    // 如果只有一张图，则不显示圆点
    _pageControl.hidesForSinglePage = YES;
    
    // 如果只有一张图，不能滚动
   // _ic.scrollEnabled = self.headerArr.count != 1;
    if (self.headerArr.count != 1) {
        _ic.scrollEnabled = YES;
    } else {
        _ic.scrollEnabled = NO;
    }
    _pageControl.pageIndicatorTintColor = [UIColor redColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor blueColor];
    
    if (self.headerArr.count > 1) {
        
        _timer = [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
            [_ic scrollToItemAtIndex:_ic.currentItemIndex+1 animated:YES];
        } repeats:YES];
        
    }
    
    // 小圆点 不能和用户交互
    _pageControl.userInteractionEnabled = NO;
    return headerView;
}

#pragma mark -- iCarousel Delegate
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{


    return self.headerArr.count;
   

}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{

    if (!view) {
        view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight *1/3 - 35)];
        UIImageView *imageView = [UIImageView new];
        [view addSubview:imageView];
        imageView.tag = 100;
        imageView.contentMode = 2;
        view.clipsToBounds = YES;
        [imageView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    VideoHeaderModel *model =self.headerArr[carousel.currentItemIndex];
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    [imageView sd_setImageWithURL:[NSURL URLWithString:model.image] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    return view;

}

// 允许循环滚动
//- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value{
//
//    if (option == iCarouselOptionWrap) {
//        return YES;
//    }
//    return value;
//}
//
// 监控当前滚动到第几个
//- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel {
////    VideoHeaderModel *model = [[VideoHeaderModel alloc] showDataWithModel:model];
////    _titleLable.text = model.title;
//    VideoHeaderModel *model = self.headerArr[carousel.currentItemIndex];
//    _titleLable.text = model.title;
//    _pageControl.currentPage = carousel.currentItemIndex;
//
//}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    
        VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VideoCellID" forIndexPath:indexPath];
        
        VideoModel *model = self.dataArr[indexPath.row];
        
        [cell showDataWithModel:model andIndexPath:indexPath];
        
            return cell;
}

#pragma  mark -- TableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 225;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    VideoModel *model = self.dataArr[indexPath.row];

    PlayViewController *vc = [[PlayViewController alloc] initWithModel:model];
    
    [self presentViewController:vc animated:YES completion:nil];


}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
