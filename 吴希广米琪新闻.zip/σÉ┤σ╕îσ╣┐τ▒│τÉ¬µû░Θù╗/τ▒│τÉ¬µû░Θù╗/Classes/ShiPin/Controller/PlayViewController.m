//
//  PlayViewController.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "PlayViewController.h"
#import "VideoModel.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "KrVideoPlayerController.h"
#import "RelevantView.h"
#import <MediaPlayer/MediaPlayer.h>

@interface PlayViewController ()

@property (nonatomic, strong) VideoModel *model;
@property (nonatomic, strong) UIImageView *imageView;


@end

@implementation PlayViewController

- (VideoModel *)model{

    if (!_model) {
        _model = [[VideoModel alloc] init];
    }
    return _model;

}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addUI];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(lateViewNotification:) name:@"relateView" object:nil];
}

- (void)lateViewNotification:(NSNotification *)notification {
    
    NSString *relateStr = [notification object];
    self.model.guid = relateStr;
    [self setRequestUrl];
}

- (id)initWithModel:(VideoModel *)model{

    _model = model;
    return self;
}

- (void)addUI{
    
    
    UIView *baceView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    baceView.backgroundColor = [UIColor whiteColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 20, 60, 44);
    [button setTitle:@" < 返回" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    [button addTarget:self action:@selector(backButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [baceView addSubview:button];
    
    [self.view addSubview:baceView];
    
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight / 3)];
    _imageView.userInteractionEnabled = YES;
    _imageView.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:_imageView];
    
    
    CGRect frame = CGRectMake(0, kScreenHeight / 3 + 64 +5, kScreenWidth, kScreenHeight - (kScreenHeight / 3 +64));
    RelevantView *rView = [[RelevantView alloc] initWithFrame:frame url:self.model.guid];

    [self.view addSubview:rView];
    
    [self setRequestUrl];

}

- (void)backButtonClick:(UIButton *)button{

    [self.videoController dismiss];
    [self dismissViewControllerAnimated:YES completion:nil];
    

}

- (void)setRequestUrl{

    NSString *requestUrl = [NSString stringWithFormat:@"http://vcsp.ifeng.com/vcsp/appData/videoGuid.do?guid=%@",self.model.guid];
    [self startRequestWitnRequestUrl:requestUrl];


}

- (void)startRequestWitnRequestUrl:(NSString *)requestUrl{

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:requestUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        NSDictionary *videoFilesDic = responseObject[@"videoFiles"];
        
        NSDictionary *imageDic = videoFilesDic[@"130"];
        NSString *imageStr = imageDic[@"mediaUrl"];
        
        NSDictionary *playDic = videoFilesDic[@"273"];
        NSString *playStr = playDic[@"mediaUrl"];
        
        [self playVidelWithUrl:playStr andImageUrl:imageStr];
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
    }];


}

- (void)playVidelWithUrl:(NSString *)playStr andImageUrl:(NSString *)imageUrl {
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:imageUrl] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    
    NSURL *url = [NSURL URLWithString:playStr];
    [self addPlayWithUrl:url];
    
}

#pragma mark -- 播放功能
- (void)addPlayWithUrl:(NSURL *)url {
    
    if (!self.videoController) {
        self.videoController = [[KrVideoPlayerController alloc] initWithFrame:self.imageView.frame];
        
        __weak typeof(self)weakSelf = self;
        
        [self.videoController setDimissCompleteBlock:^{
            
            weakSelf.videoController = nil;
        }];
        
        [self.videoController setWillBackOrientationPortrait:^{
            
            [weakSelf toolbarHidden:NO];
        }];
        
        [self.videoController setWillChangeToFullscreenMode:^{
            
            [weakSelf toolbarHidden:YES];
        }];
        
        [self.view addSubview:self.videoController.view];
    }
    
    self.videoController.contentURL = url;
    
}

// 导航栏  tabBar 电池
- (void)toolbarHidden:(BOOL)Bool {
    
    self.navigationController.navigationBarHidden = Bool;
    
    self.tabBarController.tabBar.hidden = Bool;
    
    [[UIApplication sharedApplication] setStatusBarHidden:Bool withAnimation:UIStatusBarAnimationFade];
    
    
}


// 无视频提醒
- (void)doMultiButtonAlert {
    
    NSString *title = @"提醒";
    
    NSString *message = @"暂无视频";
    
    UIAlertController *alertView = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *OKaction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertView addAction:OKaction];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
