//
//  PictureModel.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "PictureModel.h"

@implementation PictureModel

@end
