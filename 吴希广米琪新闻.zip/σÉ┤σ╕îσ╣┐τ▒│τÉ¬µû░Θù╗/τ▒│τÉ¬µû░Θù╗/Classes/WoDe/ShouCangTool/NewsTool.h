//
//  NewsTool.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/6.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@class InformationModel;
@interface NewsTool : NSObject

// 返回page页的收藏数据，从1开始
+ (NSMutableArray *)collectNews:(int)page;
+ (int)collectNewsCount;

// 收藏一个
+ (void)addCollectNews:(InformationModel *)model;

// 取消一个
+ (void)removeCollectNews:(InformationModel *)model;

// 新闻是否收藏
+ (BOOL)isCollected:(InformationModel *)model;
@end
