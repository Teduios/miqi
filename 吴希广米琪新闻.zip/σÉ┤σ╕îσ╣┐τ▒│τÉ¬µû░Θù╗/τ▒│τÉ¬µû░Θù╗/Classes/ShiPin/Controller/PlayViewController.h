//
//  PlayViewController.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoModel.h"
#import "KrVideoPlayerController.h"

@interface PlayViewController : UIViewController

@property (nonatomic, strong) KrVideoPlayerController *videoController;
@property (nonatomic, copy) NSString *image;

- (id)initWithModel:(VideoModel *)model;
@end
