//
//  VideoModel.h
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoModel : NSObject

// bodyList
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *createDate; // 生成时间
@property (nonatomic, assign) NSNumber *duration; // 播放时间 秒
@property (nonatomic, strong) NSString *guid;

@end
