//
//  ShouCangController.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ShouCangController.h"
#import "NewsTool.h"
#import "InformationModel.h"
#import "InformationCell.h"
#import "InformationWebViewController.h"
#import "MyCell.h"

@interface ShouCangController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *newsArr;
@property (nonatomic, assign) int page;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) InformationModel *model;
@property (nonatomic, strong) InformationWebViewController *vc;
@property (nonatomic, strong) UIBarButtonItem *item1;
@property (nonatomic, strong) UIBarButtonItem *item2;
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) NSMutableArray *selectedArr;
@property (nonatomic, assign) int gao;

@end

@implementation ShouCangController

- (int)gao {
    if (!_gao) {
        _gao = 0;
    }
    return _gao;
}

- (UIBarButtonItem *)item1 {

    if (!_item1) {
    _item1 = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(BianJi:)];
    }

    return _item1;
}

- (UIBarButtonItem *)item2 {

    if (!_item2) {
        _item2 = [[UIBarButtonItem alloc] initWithTitle:@"全选" style:UIBarButtonItemStylePlain target:self action:@selector(QuanXuan:)];
    }
    return _item2;
}

- (NSMutableArray *)selectedArr{

    if (!_selectedArr) {
        _selectedArr = [NSMutableArray array];
    }
    return _selectedArr;

}

- (NSMutableArray *)newsArr{

    if (!_newsArr) {
        _newsArr = [NSMutableArray array];
    }

    return _newsArr;
}

- (InformationModel *)model{

    if (!_model) {
        _model = [[InformationModel alloc] init];
    }

    return _model;
}

- (InformationWebViewController *)vc{

    if (!_vc) {
        _vc = [[InformationWebViewController alloc] init];
    }
    return _vc;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ShuaXin) name:@"ShouCangNotification" object:nil];
    [self addNews];
    [self addUI];

}

- (void)addNews{

    self.page ++;
    _newsArr = [NewsTool collectNews:self.page];

    [self.tableView reloadData];

}



- (void)addUI{
    
    self.title = @"收藏";
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.gao, kScreenWidth, kScreenHeight)];
    [self.tableView registerNib:[UINib nibWithNibName:@"InformationCell" bundle:nil] forCellReuseIdentifier:@"InformationCellID"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    UIView *view = [[UIView alloc] init];
    self.tableView.tableFooterView = view;
    
    self.navigationItem.rightBarButtonItems = @[self.item1];

}


- (void)ShuaXin{
    
    for (InformationModel *model in self.selectedArr) {
        [NewsTool removeCollectNews:model];
    }
    self.gao = 64;
    self.page = 0;
    [self viewDidLoad];
    self.item1.title = @"编辑";
    self.item2.title = @"全选";
}


#pragma mark -- 编辑,全选,删除
- (void)BianJi:(UIBarButtonItem *)item{
    if ([item.title isEqualToString:@"编辑"]) {
        item.title = @"取消";
        self.navigationItem.rightBarButtonItems = @[self.item1,self.item2];
        
        self.button = [UIButton buttonWithType:UIButtonTypeCustom];
        self.button.frame = CGRectMake(0, kScreenHeight - 88, kScreenWidth, 44);
        self.button.backgroundColor = [UIColor redColor];
        [self.button setTitle:@"删除" forState:UIControlStateNormal];
        [self.button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.button addTarget:self action:@selector(ShanChu:) forControlEvents:UIControlEventTouchDown];
        [self.view addSubview:self.button];
        
    }else{
    
        item.title = @"编辑";
        self.navigationItem.rightBarButtonItems = @[self.item1];
        self.button.hidden = YES;
    
    }
    
    [self.tableView setEditing:!self.tableView.editing animated:YES];
}


- (void)QuanXuan:(UIBarButtonItem *)item{
    
    if ([item.title isEqualToString:@"全选"]) {
        item.title = @"取消全选";
        [self allCellIsSelected:YES];
        [self.selectedArr addObjectsFromArray:self.newsArr];
    }else{
    
        item.title = @"全选";
        [self allCellIsSelected:NO];
        [self.selectedArr removeAllObjects];
    
    }

}

- (void)ShanChu:(UIButton *)button{

    for (InformationModel *model in self.selectedArr) {
        [NewsTool removeCollectNews:model];
    }
    self.gao = 64;
    self.page = 0;
    [self viewDidLoad];
    self.item1.title = @"编辑";
    self.item2.title = @"全选";

}

// 全选设置
- (void)allCellIsSelected:(BOOL)selected{

    NSArray *anArrayOfIndexPath = [NSArray arrayWithArray:[self.tableView indexPathsForVisibleRows]];
    for (int i = 0; i < [anArrayOfIndexPath count]; i++) {
        NSIndexPath *indexPath= [anArrayOfIndexPath objectAtIndex:i];
        MyCell *cell = (MyCell *)[self.tableView cellForRowAtIndexPath:indexPath];
        
        [cell setSelected:selected];
    }


}


#pragma mark -- tableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.newsArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    InformationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"InformationCellID" forIndexPath:indexPath];
    self.model = self.newsArr[indexPath.row];
    [cell showDataWithModel:self.model andIndexPath:indexPath];
    
    return cell;
}


#pragma mark -- tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    self.model = self.newsArr[indexPath.row];
    self.vc = [[InformationWebViewController alloc] initWithModel:self.model];

    // 非编辑状态
    if (!self.tableView.isEditing) {
        [self presentViewController:self.vc animated:YES completion:nil];
    }
    
    if (self.tableView.isEditing) {
        
        [self.selectedArr addObject:self.model];
    }

}

// tableView点击再点击时响应方法
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [self.selectedArr removeObject:self.model];
}



#pragma mark -- tableView的删除,文字设置及多行删除设置
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.newsArr removeObjectAtIndex:[indexPath row]];
        
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationTop];
    }
    
    [NewsTool removeCollectNews:self.model];
    
    [self.tableView reloadData];
    
}

// tableView删除前调用的方法
- (void)tableView:(UITableView *)tableView willBeginEditingRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    
    
}

// tableView删除后调用的方法
- (void)tableView:(UITableView *)tableView didEndEditingRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
}


// 改变删除时的文字
- (NSString *)tableView:(UITableView *)tableView

titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return @"删除";
}


// tableView的多选设置方法
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([self.item1.title isEqualToString:@"取消"]) {
        return UITableViewCellEditingStyleDelete | UITableViewCellEditingStyleInsert;
    }else {
        
        return UITableViewCellEditingStyleDelete;
        
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
