//
//  VideoHeaderCell.h
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoHeaderModel.h"

@interface VideoHeaderCell : UITableViewCell

@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *title;


- (void)showDataWithModel:(VideoHeaderModel *)model andIndexPath:(NSIndexPath *)indexPath;

@end
