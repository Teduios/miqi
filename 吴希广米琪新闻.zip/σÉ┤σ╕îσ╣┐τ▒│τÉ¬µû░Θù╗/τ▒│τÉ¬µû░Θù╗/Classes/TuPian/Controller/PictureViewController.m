//
//  PictureViewController.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "PictureViewController.h"

#import "PictureModel.h"
#import "PictureSingularCell.h"
#import "PictureDoubleCell.h"
#import "PictureDetailsController.h"

#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD+MJ.h"
#import "MJRefresh.h"
#import "MMProgressHUD.h"

@interface PictureViewController ()

@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, assign) NSInteger page;

@property (nonatomic) BOOL isRefreshing;
@property (nonatomic) BOOL isLoadMore;

@end

@implementation PictureViewController

- (NSMutableArray *)dataArr {

    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;

}

//-(NSNumber *)page{
//
//    if (!_page) {
//        _page = [NSNumber numberWithInt:1];
//    }
//    return _page;
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addUI];
    [self fristDownlode];
    [self addRefresh];

}

- (void)addUI {
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PictureSingularCell" bundle:nil] forCellReuseIdentifier:@"PictureSingularCellID"];
    [self.tableView registerNib:[UINib nibWithNibName:@"PictureDoubleCell" bundle:nil] forCellReuseIdentifier:@"PictureDoubleCellID"];

}

- (void)addRefresh {
    
    __weak typeof(self) weakSelf = self;
    // 下拉刷新
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        if (weakSelf.isRefreshing) {
            return ;
        }
        weakSelf.page = 1;
        weakSelf.isRefreshing = YES;
        
        NSString *url =[NSString stringWithFormat:self.requestUrl,self.page];
        [self addDownlodeDataWithUrl:url isRefreshing:YES];

        // 结束刷新
        [self endRefreshing];
        
        //        // 模拟延迟加载数据，因此2秒后才调用（真实开发中，可以移除这段gcd代码）
        //        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //
        //            });
    }];
    
    // 设置自动切换透明度(在导航栏下面自动隐藏)
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    
    // 上拉刷新
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        if (weakSelf.isLoadMore) {
            return ;
        }
        weakSelf.page ++;
        weakSelf.isLoadMore = YES;
        
        NSString *url = [NSString stringWithFormat:self.requestUrl,self.page];
        [self addDownlodeDataWithUrl:url isRefreshing:YES];
        
        // 结束刷新
        [self endRefreshing];
        
    }];
    
}

- (void)endRefreshing {
    if (self.isRefreshing) {
        self.isRefreshing = NO;//标记刷新结束
        //正在刷新 就结束刷新
        [self.tableView.mj_header endRefreshing];
    }
    if (self.isLoadMore) {
        self.isLoadMore = NO;
        [self.tableView.mj_footer endRefreshing];
    }
}

- (void)fristDownlode {

    NSString *url = self.requestUrl;
    NSString *newUrl = [NSString stringWithFormat:url,self.page];
    
    [self addDownlodeDataWithUrl:newUrl isRefreshing:NO];


}

- (void)addDownlodeDataWithUrl:(NSString *)url isRefreshing:(BOOL)isRefreshing{
    
    NSArray *arr = [url componentsSeparatedByString:@"?"];
    NSString *baseUrl = [arr firstObject];

    NSString *para = [arr lastObject];

    NSArray *paras = [para componentsSeparatedByString:@"&"];
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    for (int i = 0; i < paras.count; i++) {
        NSString *abc = paras[i];
        NSArray *abd = [abc componentsSeparatedByString:@"="];
        dic[abd[0]] = abd[1];
    }

//    //*下载动画
//    [MMProgressHUD setPresentationStyle:MMProgressHUDPresentationStyleFade];
//    [MMProgressHUD showWithTitle:@"请等待" status:@"加载中..."];

    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager GET:baseUrl parameters:dic success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        if (self.page == 1) {
            [self.dataArr removeAllObjects];
        }

        NSArray *array = responseObject[@"data"];
        for (NSDictionary *dict in array) {
            
            PictureModel *model = [[PictureModel alloc] init];
            model.title = dict[@"title"];
            model.images_count = dict[@"images_count"];
            model.images = dict[@"images"];
            model.id = dict[@"id"];
            
            [self.dataArr addObject:model];
        }
        
        [self.tableView reloadData];
        [MBProgressHUD showSuccess:@"加载成功" toView:self.view];
//        [MMProgressHUD dismissWithSuccess:@"加载成功" title:@"OK"];
        
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        
          [MBProgressHUD showError:@"加载失败" toView:self.view];
//        [MMProgressHUD dismissWithSuccess:@"加载失败" title:@"OK"];
        
        
    }];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PictureSingularCell *cell = (indexPath.row % 2 == 0 ? [tableView dequeueReusableCellWithIdentifier:@"PictureSingularCellID" forIndexPath:indexPath] : [tableView dequeueReusableCellWithIdentifier:@"PictureDoubleCellID" forIndexPath:indexPath]);
    
    PictureModel *model = self.dataArr[indexPath.row];
    
    [cell showDataWithModel:model andIndexPath:indexPath];
    
    return cell;
}


#pragma mark -- TableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 180;

}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    PictureModel *model = self.dataArr[indexPath.row];
    PictureDetailsController *vc = [[PictureDetailsController alloc] initWithImageID:model.id];
    [self.navigationController pushViewController:vc animated:YES];

}


@end
