//
//  VideoCell.m
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "VideoCell.h"
#import "UIImageView+WebCache.h"


@implementation VideoCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)showDataWithModel:(VideoModel *)model andIndexPath:(NSIndexPath *)indexPath {

    [self.imageUrl sd_setImageWithURL:[NSURL URLWithString:model.image] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    self.titleLable.text = model.title;
    
    NSString *str = [model.createDate substringToIndex:10];
    self.timeLable.text = str;
    
    int playTime = [model.duration intValue];

    self.playNumLable.text = [NSString stringWithFormat:@"%d分%d秒",(playTime / 60),(playTime % 60)];
    

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
