//
//  PictureDetailsController.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "PictureDetailsController.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "imageModel.h"

@interface PictureDetailsController ()

@property (nonatomic, strong) NSArray *imageArray;
@property (nonatomic, copy) NSString *id;
@property (nonatomic, assign) NSNumber *imageCount;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation PictureDetailsController

- (NSArray *)imageArray {
    if (!_imageArray) {
        _imageArray = [[NSArray alloc] init];
    }
    return _imageArray;
    
}


- (id)initWithImageID:(NSString *)id {
    
    _id = id;
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = kRGBColor(240, 240, 240);
    [self doewLodeImage];
}

- (void)addUI {
    
    self.title = @"图片详情";
    // 创建滚动视图
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    // 无回弹
    self.scrollView.bounces = NO;
    
    // 无滚动条
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    // 整页滚动
    self.scrollView.pagingEnabled = YES;
    // 大小
    self.scrollView.contentSize = CGSizeMake(kScreenWidth  * [self.imageCount doubleValue], kScreenWidth);
    
    [self.view addSubview:self.scrollView];
    
    if ([self.imageCount.stringValue isEqual:@"0"]) {
        [self.scrollView removeFromSuperview];
        [self setEmptyPage];
    }
    
    
}

#pragma mark -- 没有图片提示用户
- (void)setEmptyPage {
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 50, kScreenWidth -10, kScreenHeight - 100)];
    imageView.image = [UIImage imageNamed:@"news0.png"];
    
    [self.view addSubview:imageView];
}

#pragma mark -- 请求数据
- (void)doewLodeImage{
    
    NSString *postUrl = [NSString stringWithFormat:@"http://api.3g.huanqiu.com/cms/index.php?r=api/getArticleById&id=%@",self.id];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    // NSDictionary *parameters = @{@"r":@"api/getArticleById", @"id":self.id};
    
    [manager GET:postUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        
        NSDictionary *dicapp = responseObject[@"data"];
        
        imageModel *model = [[imageModel alloc] init];
        [model setValuesForKeysWithDictionary:dicapp];
        
        // 获取图片个数
        self.imageArray = responseObject[@"data"][@"images"];
        NSNumber *a = [NSNumber numberWithInt:self.imageArray.count];
        self.imageCount = a;
        
        [self addUI];
        
        
        for (int i = 0; i < [self.imageCount intValue]; i++) {
            self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * self.view.frame.size.width, 0, self.view.frame.size.width, self.view.frame.size.height - 100)];
            
            [self.imageView sd_setImageWithURL:[NSURL URLWithString:[model.images[i]objectForKey:@"url"]] placeholderImage:[UIImage imageNamed:@"news0"]];
            
            [self.scrollView addSubview:self.imageView];
            
        }
        
        UILabel *lable = [[UILabel alloc] init];
        lable.frame = CGRectMake(0, self.view.frame.size.height - 100, self.view.frame.size.width, 100);
        
        lable.font = [UIFont fontWithName:@"HelveticaNeue" size:17];
        
        lable.lineBreakMode = NSLineBreakByWordWrapping;
        lable.numberOfLines = 0;
        lable.textColor = [UIColor redColor];
        lable.backgroundColor = [UIColor blackColor];
        
        lable.text = dicapp[@"title"];
        
        
        
        //        UILabel *lable2 = [[UILabel alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height / 1.8 + 20, self.view.frame.size.width, self.view.frame.size.height - (self.view.frame.size.height / 1.8 +20))];
        //        lable2.font = [UIFont systemFontOfSize:14];
        //        lable2.lineBreakMode = NSLineBreakByWordWrapping;
        //        lable2.numberOfLines = 0;
        //        lable2.text = dicapp[@"content"];
        
        [self.view addSubview:lable];
        //        [self.view addSubview:lable2];
        
        
        // NSLog(@"JSON: %@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        // NSLog(@"Error: %@", error);
    }];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
