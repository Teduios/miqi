//
//  NewsTool.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/6.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NewsTool.h"
#import "FMDB.h"
#import "InformationModel.h"

@implementation NewsTool

static FMDatabase *_db;

+ (void)initialize {
    
    // 打开数据库
    NSString *file = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject] stringByAppendingPathComponent:@"news.sqlite"];
    
    //    NSLog(@"dizhi:%@", file);
    _db = [FMDatabase databaseWithPath:file];
    
    if (![_db open]) {
        return;
    }
    
    // 创表
    [_db executeUpdate:@"CREATE TABLE IF NOT EXISTS t_collect_news(id integer PRIMARY KEY, news blob, detailUrl text);"];
    
    //[_db executeUpdate:@"CREATE TABLE IF NOT EXISTS t_recent_news(id integer PRIMARY KEY, news blob NOT NULL, detailUrl text NOT NULL);"];
}


+ (NSMutableArray *)collectNews:(int)page {
    
    int size = 20;
    int pos = (page - 1) * size;
    FMResultSet *set = [_db executeQueryWithFormat:@"SELECT * FROM t_collect_news ORDER BY id DESC LIMIT %d,%d;",pos, size];
    NSMutableArray *newsArr = [NSMutableArray array];
    NSLog(@"%d",set.columnCount);
    while (set.next) {
        InformationModel *model = [NSKeyedUnarchiver unarchiveObjectWithData:[set objectForColumnName:@"news"]];
        [newsArr addObject:model];
        NSLog(@"newsArr:%lu",(unsigned long)newsArr.count);
    }
    
    return newsArr;
}


+ (void)addCollectNews:(InformationModel *)model {
    
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:model];
    
    [_db executeUpdateWithFormat:@"INSERT INTO t_collect_news(news,detailUrl) VALUES(%@,%@);",data, model.detailUrl];
    
}


+ (void)removeCollectNews:(InformationModel *)model {
    
    [ _db executeUpdateWithFormat:@"DELETE FROM t_collect_news WHERE detailUrl = %@",model.detailUrl];
    
}


+(BOOL)isCollected:(InformationModel *)model {
    
    FMResultSet *set = [_db executeQueryWithFormat:@"SELECT count(*) AS news_count FROM t_collect_news WHERE detailUrl = %@",model.detailUrl];
    
    [set next];
    
    return [set intForColumn:@"news_count"] == 1;
}


+ (int)collectNewsCount {
    
    
    FMResultSet *set = [_db executeQueryWithFormat:@"SELECT count(*) AS news_count FROM t_collect_news"];
    [set next];
    
    return [set intForColumn:@"news_count"];
    
}

@end
