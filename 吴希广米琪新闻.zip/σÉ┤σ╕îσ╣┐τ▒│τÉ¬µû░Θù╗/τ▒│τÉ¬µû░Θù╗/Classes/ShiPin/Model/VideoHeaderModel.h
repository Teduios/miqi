//
//  VideoHeaderModel.h
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoHeaderModel : NSObject

// Header
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *image;

- (id)showDataWithModel:(VideoHeaderModel *)model;

@end
