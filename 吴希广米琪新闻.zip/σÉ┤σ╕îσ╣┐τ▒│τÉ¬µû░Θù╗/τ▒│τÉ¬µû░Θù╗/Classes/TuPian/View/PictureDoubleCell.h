//
//  PictureDoubleCell.h
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PictureModel.h"


@interface PictureDoubleCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageUrl1;
@property (weak, nonatomic) IBOutlet UIImageView *imageUrl2;
@property (weak, nonatomic) IBOutlet UIImageView *imageUrl3;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *dateLable;


- (void)showDataWithModel:(PictureModel *)model andIndexPath:(NSIndexPath *)indexPath;


@end
