//
//  MyViewController.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "MyViewController.h"
#import "CExpandHeader.h"
#import "SDImageCache.h"
#import "MyCell.h"

#import "ShouCangController.h"

@interface MyViewController ()<UIActionSheetDelegate>

@property (nonatomic, strong) CExpandHeader *headerView;

@end

@implementation MyViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self addUI];

}

- (void)addUI {

    [self.tableView registerNib:[UINib nibWithNibName:@"MyCell" bundle:nil] forCellReuseIdentifier:@"MyCellID"];
//    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 220)];
    [imageView setImage:[UIImage imageNamed:@"header.png"]];
    
    self.headerView = [CExpandHeader expandWithScrollView:self.tableView expandView:imageView];
    UIView *view = [UIView new];
    self.tableView.tableFooterView = view;

}

#pragma mark -- tableView data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCellID" forIndexPath:indexPath];
    switch (indexPath.row) {
        case 0:{
        
            cell.MyImageView.image = [UIImage imageNamed:@"collect.png"];
            cell.MyLable.text = @"我的收藏";
        }
            
            break;
        case 1:{
            cell.MyImageView.image = [UIImage imageNamed:@"qinghuan.png"];
            cell.MyLable.text = @"清除缓存";
        
        }
            break;
            
        case 2:{
            cell.MyImageView.image = [UIImage imageNamed:@"tel_green.png"];
            cell.MyLable.text = @"联系我们：wuxiguangll@163.com";
//            // 设置cell不可选
//            // cell.userInteractionEnabled= FALSE;
//            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        }
            break;
        default:
            break;
    }

    return cell;
}


#pragma mark -- tableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    return 50;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    switch (indexPath.row) {
        case 0:
        {
        
            [self pushShouCangController];
        
        }
            break;
            
        case 1:
        {
        
            [self pushAlertController];
        }
            
        default:
            break;
    }

}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath{

    return (indexPath.row == 2 ? NO : YES);
}

- (void)pushAlertController {

    NSString *title = @"提示";
    NSString *message = [NSString stringWithFormat:@"删除缓存文件:%.2fM",[self getCacheSize]];
    NSString *okButtonTitle = @"删除";
    NSString *neverButtonTitle = @"取消";
    
    // 初始化
    UIAlertController *alertView = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleActionSheet];
    
    // 创建点击操作
    UIAlertAction *neverAction = [UIAlertAction actionWithTitle:neverButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {

    }];
    
    // 红色删除样式
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:okButtonTitle style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {

        // 删除第三方的缓存
        [[SDImageCache sharedImageCache] clearMemory];
        [[SDImageCache sharedImageCache] clearDisk];
        // 删除自己产生的缓存
        NSString *myCachePath = [NSHomeDirectory() stringByAppendingFormat:@"/Library/Caches/MyCaches"];
        [[NSFileManager defaultManager] removeItemAtPath:myCachePath error:nil];
        
    }];

    [alertView addAction:neverAction];
    [alertView addAction:okAction];
    
    [self presentViewController:alertView animated:YES completion:nil];

}

// 获取缓存大小
- (double)getCacheSize{

    double sdSize = [[SDImageCache sharedImageCache] getSize];
    NSString *myCachePath = [NSHomeDirectory() stringByAppendingFormat:@"/Library/Caches/MyCaches"];
    NSDirectoryEnumerator *enumerator = [[NSFileManager defaultManager] enumeratorAtPath:myCachePath];
    double mySize = 0;
    for (NSString *fileName in enumerator) {
        NSString *filePath = [myCachePath stringByAppendingPathComponent:fileName];
        NSDictionary *dict = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
        mySize += dict.fileSize;
    }
    
    double totaSize = (mySize + sdSize)/1024/1024;
    return totaSize;

}

- (void)pushShouCangController{

    ShouCangController *vc = [[ShouCangController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
