//
//  InformationWebViewController.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "InformationWebViewController.h"

#import "InformationModel.h"
#import "UMSocial.h"
#import "MBProgressHUD+MJ.h"
#import "NewsTool.h"
#import "ShouCangController.h"

@interface InformationWebViewController ()

@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) UIButton *CollectionButton;
@property (nonatomic, strong) InformationModel *model;


@end

@implementation InformationWebViewController

- (InformationModel *)model {

    if (!_model) {
        _model = [[InformationModel alloc] init];
    }

    return _model;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addUI];
    
}

- (id)initWithModel:(InformationModel *)model{

    self.model = model;
    return self;

}


- (void)addUI{
    
    // 头部View
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, 64)];
    [self.view addSubview:headerView];
    
    // 返回按钮
    UIButton *backbutton = [UIButton buttonWithType:UIButtonTypeCustom];
    backbutton.frame = CGRectMake(5, 20, 60, 44);
    [backbutton setTitle:@"< 返回" forState:UIControlStateNormal];
    [backbutton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [backbutton addTarget:self action:@selector(FanHui:) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview:backbutton];
    
    // 分享按钮
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shareButton.frame = CGRectMake(kScreenWidth - 60, 20, 55, 44);
    [shareButton setTitle:@"分享" forState:UIControlStateNormal];
    [shareButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [shareButton addTarget:self action:@selector(FenXiang:) forControlEvents:UIControlEventTouchDown];
    [headerView addSubview:shareButton];
    
    // 收藏按钮
    self.CollectionButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.CollectionButton.frame = CGRectMake(kScreenWidth - 120, 20, 55, 44);
    [self.CollectionButton setTitle:@"收藏" forState:UIControlStateNormal];
    [self.CollectionButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.CollectionButton setTitle:@"已收藏" forState:UIControlStateSelected];
    [self.CollectionButton setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
    [self.CollectionButton addTarget:self action:@selector(ShouCang:) forControlEvents:UIControlEventTouchDown];
    [headerView addSubview:self.CollectionButton];
    
    
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, kScreenWidth, kScreenHeight - 64)];
    [self.view addSubview:self.webView];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:self.model.detailUrl]];
    [self.webView loadRequest:request];
    
    // 设置收藏状态
    self.CollectionButton.selected = [NewsTool isCollected:self.model];
    

}

- (void)FanHui:(UIButton *)button{

    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)FenXiang:(UIButton *)button{

    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"565a7ac5e0f55a6ba00030cd"
                                      shareText:@"请输入分享的内容"
                                     shareImage:[UIImage imageNamed:@"image0.png"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToWechatSession,UMShareToQQ,nil]
                                       delegate:nil];

}

- (void)ShouCang:(UIButton *)button{
    
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    info[@"NewsCollectKey"] = self.model;
    if (button.isSelected) {
        [NewsTool removeCollectNews:self.model];
        [MBProgressHUD showSuccess:@"取消收藏成功" toView:self.view];
        
    }else {
        
        [NewsTool addCollectNews:self.model];
        [MBProgressHUD showSuccess:@"收藏成功" toView:self.view];
        
    }
    button.selected = !button.isSelected;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ShouCangNotification" object:nil userInfo:info];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
