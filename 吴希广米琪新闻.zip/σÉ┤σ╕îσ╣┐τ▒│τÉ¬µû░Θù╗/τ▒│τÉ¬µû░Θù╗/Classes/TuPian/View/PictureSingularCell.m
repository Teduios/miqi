//
//  PictureSingularCell.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "PictureSingularCell.h"
#import "UIImageView+WebCache.h"

@implementation PictureSingularCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)showDataWithModel:(PictureModel *)model andIndexPath:(NSIndexPath *)indexPath {

    if (model.images.count > 0) {
        [self.imageUrl1 sd_setImageWithURL:[NSURL URLWithString:model.images[0]] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    }
    
    if (model.images.count > 1) {
        [self.imageUrl2 sd_setImageWithURL:[NSURL URLWithString:model.images[1]] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    }
    if (model.images.count > 2) {
        [self.imageUrl3 sd_setImageWithURL:[NSURL URLWithString:model.images[2]] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    }
    
    self.titleLable.text = model.title;
    self.dateLable.text = [NSString stringWithFormat:@"共有图片 %@ 张",model.images_count];
    

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
