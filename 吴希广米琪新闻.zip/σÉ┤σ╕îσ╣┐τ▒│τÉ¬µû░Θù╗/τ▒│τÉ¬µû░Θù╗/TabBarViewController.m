//
//  TabBarViewController.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "TabBarViewController.h"

#import "WMPageController.h"

#import "InformationViewController.h"
#import "PictureViewController.h"
#import "VideoViewController.h"
#import "MyViewController.h"

@interface TabBarViewController ()

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addViewController];
    // Do any additional setup after loading the view.
}

- (void)addViewController{

    // 创建tabBar的ViewControllers容器
    NSMutableArray *TabBarControllersArr = [NSMutableArray array];
    
    //1, 资讯界面
    NSArray *informationTitlesArr = @[@"要闻",
                                      @"时政",
                                      @"军事",
                                      @"体育",
                                      @"财经",
                                      @"社会",
                                    
                                      ];
    
    NSArray *informationUrl = @[kInformationYaoWen,
                                kInformationShiZheng,
                                kInformationJunShi,
                                kInformationTiYu,
                                
                                kInformationCaiJing,
                                kInformationSheHui,
                                
                                ];
    // 用来存储每个标题对应的视图
    NSMutableArray *informationmArr = [NSMutableArray array];
    
    // 数据基本相同，界面相同，所以用同一个视图
    for (int i = 0; i < informationTitlesArr.count; i++) {
        
        InformationViewController *vc = [[InformationViewController alloc] init];
        vc.requestUrl = informationUrl[i];
        [informationmArr addObject:vc];
    }
    
    WMPageController *pageVC = [[WMPageController alloc] initWithViewControllers:informationmArr andTheirTitles:informationTitlesArr];
    UINavigationController *nav1 = [[UINavigationController alloc] initWithRootViewController:pageVC];
    pageVC.title = @"资讯";
    // 资讯tabbar设置
    pageVC.tabBarItem.title = @"资讯";
    pageVC.tabBarItem.image = [[UIImage imageNamed:@"tabbar_news"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    pageVC.tabBarItem.selectedImage = [[UIImage imageNamed:@"tabbar_news_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    pageVC.menuY = 0; //菜单标题Y值
    pageVC.titleSizeSelected = 17; //菜单选中时字体大小
    pageVC.pageAnimatable = NO; //点击相邻的MenuItem是否触发翻页动画(当当前选中与点击Item相差大于1是不触发)
    pageVC.menuItemWidth = 60; //设置菜单标题宽
    pageVC.menuViewStyle = WMMenuViewStyleLine; //菜单的选中跟踪条
    
    
    // 放入tabBar数组
    [TabBarControllersArr addObject:nav1];
    
    
    //2, 图片界面
    NSArray *pictureTitles = @[ @"时政",
                                @"生活",
                                @"军事",
                                @"视觉",
                                ];
    NSArray *picUrl = @[ kTuPianShiZheng,
                         kTuPianShengHuo,
                         kTuPianJunShi,
                         kTuPianShiJue,
                        ];
    NSMutableArray *picturemArr = [NSMutableArray array];
    
    for (int i = 0; i < pictureTitles.count; i++) {
        
        PictureViewController *vc = [[PictureViewController alloc] init];
        vc.requestUrl = picUrl[i];
        [picturemArr addObject:vc];
    }
    
    WMPageController *pageVC2 = [[WMPageController alloc] initWithViewControllers:picturemArr andTheirTitles:pictureTitles];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:pageVC2];
    
    pageVC2.title = @"图片";
    pageVC2.tabBarItem.title = @"图片";
    
    // tabBar设置
    pageVC2.tabBarItem.image = [[UIImage imageNamed:@"tabbar_picture"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    pageVC2.tabBarItem.selectedImage = [[UIImage imageNamed:@"tabbar_picture_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    //pageVC2.menuY = 0;
    pageVC2.titleSizeSelected = 17;
    pageVC2.pageAnimatable = NO;
    pageVC2.menuItemWidth = kScreenWidth/4;
    pageVC2.menuViewStyle = WMMenuViewStyleLine;
    
    [TabBarControllersArr addObject:nav2];
    
    //3, 视频界面
    VideoViewController *VideoVC = [[VideoViewController alloc] init];
    
    VideoVC.tabBarItem.image = [[UIImage imageNamed:@"tabbar_video"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    VideoVC.tabBarItem.selectedImage= [[UIImage imageNamed:@"tabbar_video_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    VideoVC.title = @"视频";
    
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:VideoVC];
    
    [TabBarControllersArr addObject:nav3];
    
    
    //4， 我的
    MyViewController *myViewController = [[MyViewController alloc]init];
    myViewController.tabBarItem.image = [[UIImage imageNamed:@"tabbar_setting"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    myViewController.tabBarItem.selectedImage= [[UIImage imageNamed:@"tabbar_setting_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    myViewController.title = @"我的";
    
    UINavigationController *nav4 = [[UINavigationController alloc]initWithRootViewController:myViewController];
    
    //nav4.navigationBar.barTintColor = [UIColor redColor];
    
    [TabBarControllersArr addObject:nav4];
    
#pragma mark -- 设置Tabbar背景
    // 填充色
    self.tabBar.tintColor = [UIColor redColor];
    //self.tabBar.barTintColor = [UIColor blackColor];
    
    self.viewControllers = TabBarControllersArr;

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
