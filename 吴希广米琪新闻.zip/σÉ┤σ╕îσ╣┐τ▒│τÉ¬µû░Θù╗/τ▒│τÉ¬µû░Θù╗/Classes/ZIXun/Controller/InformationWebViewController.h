//
//  InformationWebViewController.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InformationModel.h"


@interface InformationWebViewController : UIViewController

- (id)initWithModel:(InformationModel *)model;

@end
