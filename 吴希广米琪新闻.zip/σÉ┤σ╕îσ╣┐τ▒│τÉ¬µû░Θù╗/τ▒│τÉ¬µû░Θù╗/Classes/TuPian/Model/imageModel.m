//
//  imageModel.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "imageModel.h"

@implementation imageModel

+ (id)showWithImageUrl:(NSDictionary *)dict {
    
    return [[self alloc] initWithImageUrl:dict];
    
}


- (id)initWithImageUrl:(NSDictionary *)dict {
    if (self = [super init]) {
        
        self.url = dict[@"url"];
        self.url1 = dict[@"url1"];
        self.title = dict[@"title"];
    }
    return self;
    
}

@end
