//
//  PictureDetailsController.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PictureDetailsController : UIViewController

- (id) initWithImageID:(NSString *)id;

@end
