//
//  InformationModel.h
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InformationModel : NSObject

@property (nonatomic, copy) NSString *imgUrl1;
@property (nonatomic, copy) NSString *itemTitle;
@property (nonatomic, copy) NSString *brief;
@property (nonatomic, copy) NSString *detailUrl;
@property (nonatomic, copy) NSString *itemID;


@end
