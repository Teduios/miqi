//
//  RelevantCell.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "RelevantCell.h"
#import "UIImageView+WebCache.h"

@implementation RelevantCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)showDataWithModel:(RelevantModel *)model{
    
    [self.imageUrlView sd_setImageWithURL:[NSURL URLWithString:model.mediaUrl] placeholderImage:[UIImage imageNamed:@"news0.png"]];
    
    self.titleLable.text = model.name;
    self.createDateLable.text = model.createDate;


}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
