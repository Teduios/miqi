//
//  MyCell.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
