//
//  Header.h
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#ifndef Header_h
#define Header_h

//####1. 1-1新闻 要闻_________________________________________
#define kInformationYaoWen @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1372928688333145&n1=1&n2=20&toutuNum=%d"

//1-2. 新闻 时政
#define kInformationShiZheng @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1414661661499136&n1=1&n2=20&toutuNum=%d"

//1-3.新闻  军事
#define kInformationJunShi @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1383125722766236&n1=1&n2=20&toutuNum=%d"

//1-4.新闻 体育
#define kInformationTiYu @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1383126274316527&n1=1&n2=20&toutuNum=%d"

//1-5.新闻财经
#define kInformationCaiJing @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1383126577835657&n1=1&n2=20&toutuNum=%d"

//1-6.新闻 社会
#define kInformationSheHui @"http://hot.news.cntv.cn/index.php?controller=list&action=getHandDataInfoNew&handdata_id=TDAT1383126850500788&n1=1&n2=20&toutuNum=%d"

//1-7.图片
#define kInformationTuPian @"http://hot.news.cntv.cn/index.php?controller=list&action=morelist&handdata_id=TDAT1373943452289972&n=20"




//####2.图片新闻_________________________________________
#define kTuPian @"http://hot.news.cntv.cn/index.php?controller=list&action=morelist&handdata_id=TDAT1373943452289972&n=20"

//时政
#define kTuPianShiZheng @"http://api.3g.huanqiu.com/cms/index.php?r=api/getArticleByChannelId&type=3&id=139&page=%d&page_size=10"

//生活
#define kTuPianShengHuo @"http://api.3g.huanqiu.com/cms/index.php?r=api/getArticleByChannelId&type=3&id=140&page=%d&page_size=10"

//军事
#define kTuPianJunShi @"http://api.3g.huanqiu.com/cms/index.php?r=api/getArticleByChannelId&type=3&id=141&page=%d&page_size=10"

//视觉
#define kTuPianShiJue @"http://api.3g.huanqiu.com/cms/index.php?r=api/getArticleByChannelId&type=3&id=142&page=%d&page_size=10"


//####3.视频_________________________________________
//精选
#define kVideoJingXuan @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.1&isNotModified=0&useType=androidPhone&channelId=100409-0&positionId=0"
//军事
#define kVideoJunShi @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&channelId=100377-0&positionId=0"

//娱乐
#define kVideoYuLe @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&channelId=100391-0&positionId=0"

//原创
#define kVideoYuanChuang @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&channelId=127952-0&positionId=0"

//历史
#define kVideoLiShi @"http://vcsp.ifeng.com/vcsp/appData/recommendGroupByTeamid.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&channelId=100384-0&positionId=0"




//####4.纪录片_________________________________________
//探索
#define kJiLuPianTanSuo @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=100464-100469&positionNo=0"

//社会
#define kJiLuPianSheHui @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=100464-100467&positionNo=0"

//军事
#define kJiLuPianJunShi @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=100464-100465&positionNo=0"

//任务
#define kJiLuPianRenWu @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=100464-100468&positionNo=0"

//历史
#define kJiLuPianLiShi @"http://vcsp.ifeng.com/vcsp/appData/getChannelDetail.do?pageSize=20&adapterNo=6.9.0&isNotModified=0&useType=androidPhone&statisticChannelId=100464-100466&positionNo=0"

//播放地址
#define kJiLuPianBoFangAddress @"http://vcsp.ifeng.com/vcsp/appData/videoGuid.do?guid=019bea42-66d8-47b7-85e4-a95ee01d80c5"

//相关
#define kJiLuPianXianGuan @"http://vcsp.ifeng.com/vcsp/appData/getGuidRelativeVideoList.do?guid=019bea42-66d8-47b7-85e4-a95ee01d80c5&pageSize=20"

//热点
#define kJiLuPianReDian @"http://vcsp.ifeng.com/vcsp/appData/recommend.do?useType=androidPhone&channelId=hotList&pageSize=10&adapterNo=6.8.0"

//排行
#define kJiLuPianPaiHang @"http://vcsp.ifeng.com/vcsp/appData/recommend.do?useType=androidPhone&channelId=rankList&pageSize=10&adapterNo=6.8.0"



#endif /* Header_h */
