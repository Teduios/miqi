//
//  VideoHeaderCell.m
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "VideoHeaderCell.h"
#import "UIImageView+WebCache.h"

@interface VideoHeaderCell ()

@end

@implementation VideoHeaderCell

- (void)awakeFromNib {
    
    [super awakeFromNib];
    
    
    
}

- (void)showDataWithModel:(VideoHeaderModel *)model andIndexPath:(NSIndexPath *)indexPath{


}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
