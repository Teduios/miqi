//
//  InformationViewController.h
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InformationViewController : UITableViewController

//解析的网址
@property (nonatomic, copy) NSString *requestUrl;

@end
