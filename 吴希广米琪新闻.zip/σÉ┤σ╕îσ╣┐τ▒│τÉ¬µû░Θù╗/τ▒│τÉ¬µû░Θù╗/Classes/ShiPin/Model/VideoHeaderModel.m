//
//  VideoHeaderModel.m
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "VideoHeaderModel.h"

@implementation VideoHeaderModel

- (id)showDataWithModel:(VideoHeaderModel *)model {


    self.title = model.title;
    self.image = model.image;
    
    return self;

}

@end
