//
//  RelevantCell.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RelevantModel.h"

@interface RelevantCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageUrlView;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *createDateLable;

- (void)showDataWithModel:(RelevantModel *)model;
@end
