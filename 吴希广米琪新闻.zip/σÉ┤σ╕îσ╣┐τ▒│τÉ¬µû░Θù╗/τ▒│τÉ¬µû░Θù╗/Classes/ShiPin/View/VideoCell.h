//
//  VideoCell.h
//  米琪新闻
//
//  Created by tarena on 15/12/31.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoModel.h"

@interface VideoCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UIImageView *imageUrl;
@property (weak, nonatomic) IBOutlet UILabel *timeLable;
@property (weak, nonatomic) IBOutlet UILabel *playNumLable;
@property (weak, nonatomic) IBOutlet UILabel *fromeNumlable;

- (void)showDataWithModel:(VideoModel *)model andIndexPath:(NSIndexPath *)indexPath;

@end
