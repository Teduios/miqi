//
//  imageModel.h
//  米琪新闻
//
//  Created by 吴希广 on 16/1/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface imageModel : NSObject

@property (nonatomic, copy) NSString *create_time;
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *is_delete;
@property (nonatomic, copy) NSString *obj_id;
@property (nonatomic, copy) NSString *orderby;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *url1;
@property (nonatomic, strong) NSArray *images;

@property (nonatomic, copy) NSString *author;
@property (nonatomic, copy) NSString *channel;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *from_id;
@property (nonatomic, copy) NSString *from_type;
//@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *image_resize;
@property (nonatomic, copy) NSString *image_resize_b;
@property (nonatomic, copy) NSString *image_resize_s;
//@property (nonatomic, strong) NSDictionary *images;
@property (nonatomic, copy) NSString *intro;
//@property (nonatomic, copy) NSString *is_delete;
@property (nonatomic, copy) NSString *opinion;
@property (nonatomic, copy) NSString *pub_time;
@property (nonatomic, copy) NSString *share_url;
@property (nonatomic, copy) NSString *source;
@property (nonatomic, copy) NSString *status;
//@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *error_msg;


+ (id)showWithTitle:(NSDictionary *)dict;
+ (id)showWithImageUrl:(NSDictionary *)dict;
@end
