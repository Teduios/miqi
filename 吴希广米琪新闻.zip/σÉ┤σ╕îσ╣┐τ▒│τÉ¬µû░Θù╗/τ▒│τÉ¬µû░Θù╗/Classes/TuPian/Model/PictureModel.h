//
//  PictureModel.h
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PictureModel : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSNumber *images_count;
@property (nonatomic, strong) NSArray *images;
@property (nonatomic, copy) NSString *id;

@end
