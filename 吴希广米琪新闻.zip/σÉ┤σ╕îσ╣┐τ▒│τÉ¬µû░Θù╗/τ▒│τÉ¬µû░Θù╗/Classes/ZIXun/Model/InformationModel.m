//
//  InformationModel.m
//  米琪新闻
//
//  Created by tarena on 15/12/29.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "InformationModel.h"
#import "MJExtension.h"

@implementation InformationModel

MJCodingImplementation
@end
