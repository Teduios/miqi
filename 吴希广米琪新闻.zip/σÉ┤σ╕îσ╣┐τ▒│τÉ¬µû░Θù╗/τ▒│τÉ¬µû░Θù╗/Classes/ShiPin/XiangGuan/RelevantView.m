//
//  RelevantView.m
//  米琪新闻
//
//  Created by 吴希广 on 16/1/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "RelevantView.h"
#import "RelevantCell.h"
#import "RelevantModel.h"
#import "AFNetworking.h"

@implementation RelevantView{
    
    UITableView *_tableView;
    NSMutableArray *_dataArr;
    UILabel *_emptyPagelabel;
    
}

-(instancetype)initWithFrame:(CGRect)frame url:(NSString *)url{

    self = [super initWithFrame:frame];
    
    if (self) {
        
        [self addView];
        [self downLodeDataWithUrl:url];
        
    }

    return self;
}

- (void)addView {
    
    _dataArr = [NSMutableArray array];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height - 10)];
    _tableView.rowHeight = 80;
    
    UIView *view = [[UIView alloc] init];
    view.bounds = CGRectMake(0, 0, _tableView.frame.size.width, (5 - _dataArr.count) * 80);
    if (_dataArr.count < 5) {
        
        _tableView.tableFooterView = view;
    }
    
    
    [_tableView registerNib:[UINib nibWithNibName:@"RelevantCell" bundle:nil] forCellReuseIdentifier:@"RelevantCellID"];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    //    _tableView.separatorColor = [UIColor greenColor];
    //    _tableView.separatorInset = UIEdgeInsetsZero;
    
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:_tableView];
    
    
}



- (void)downLodeDataWithUrl:(NSString *)url {
    
    NSString *postUrl = [NSString stringWithFormat:@"http://vcsp.ifeng.com/vcsp/appData/getGuidRelativeVideoList.do?guid=%@&pageSize=20",url];
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager GET:postUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSArray *arr = responseObject[@"guidRelativeVideoInfo"];
        
        for (NSDictionary *pDic in arr) {
            RelevantModel *model = [[RelevantModel alloc]init];
            [model setValuesForKeysWithDictionary:pDic];
            NSArray *arr1 = pDic[@"files"];
            NSDictionary *vedioDic = arr1[1];
            if (arr1.count > 5) {
                NSDictionary *imgDic = arr1[5];
                model.mediaUrl1 = imgDic[@"mediaUrl"];
            }
            model.mediaUrl = vedioDic[@"mediaUrl"];
            [_dataArr addObject:model];
        }
        _dataArr.count == 0?[self setEmptyPage]: [_tableView reloadData];
        
        // NSLog(@"JSON: %@", responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        // NSLog(@"Error: %@", error);
        
        
    }];
    
}
//服务器没数据 显示提示
- (void)setEmptyPage{
    [_tableView removeFromSuperview];
    
    _emptyPagelabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 100, self.frame.size.width, 200)];
    _emptyPagelabel.text = @"暂无数据";
    
    //文字居中显示
    _emptyPagelabel.textAlignment = NSTextAlignmentCenter;
    
    //字体 字形
    _emptyPagelabel.font = [UIFont fontWithName:@"Courier" size:20];
    
    //字体灰色
    _emptyPagelabel.textColor = [UIColor lightGrayColor];
    
    //加到视图
    [self addSubview:_emptyPagelabel];
}

#pragma mark -- TableViewDelegate,TableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    //  NSLog(@"llll:%@",self.dataArray.count);
    return _dataArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    RelevantCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RelevantCellID" forIndexPath:indexPath];
    RelevantModel *model = _dataArr[indexPath.row];
    [cell showDataWithModel:model];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    RelevantModel *model = _dataArr[indexPath.row];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"relateView" object:model.guid];
    
    
}



@end
